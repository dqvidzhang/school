module sequential_mux(
    input clk, x, y,
    output reg A, B,
    output z
);

    wire [1:0] sel_A = {x, y};
    wire [1:0] sel_B = {x, B};

    reg A_next, B_next;  // ? must be reg, not wire

    // MUX logic for A_next using x and y
    always @(*) begin
        case (sel_A)
            2'b00: A_next = 1'b0;
            2'b01: A_next = 1'b0;
            2'b10: A_next = 1'b1;
            2'b11: A_next = B;
        endcase
    end

    // MUX logic for B_next using x and B
    always @(*) begin
        case (sel_B)
            2'b00: B_next = 1'b0;
            2'b01: B_next = 1'b0;
            2'b10: B_next = A;
            2'b11: B_next = 1'b1;
        endcase
    end

    // D flip-flops for state update
    always @(posedge clk) begin
        A <= A_next;
        B <= B_next;
    end

    assign z = A;

endmodule
