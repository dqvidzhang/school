module jk_fsm (
    input clk, x, y,
    output reg A, B,
    output z
);
    wire y_not, B_not, A_not;
    wire J_A, K_A, J_B, K_B;

    assign y_not = ~y;
    assign B_not = ~B;
    assign A_not = ~A;

    // From excitation table logic (manually derived)
    assign J_A = x & (y_not | B);
    assign K_A = ~J_A;

    assign J_B = x & (A | B_not);
    assign K_B = ~J_B;

    // JK Flip-Flops
    always @(posedge clk) begin
        A <= (J_A & A_not) | (~K_A & A);
        B <= (J_B & B_not) | (~K_B & B);
    end

    assign z = A;
endmodule
