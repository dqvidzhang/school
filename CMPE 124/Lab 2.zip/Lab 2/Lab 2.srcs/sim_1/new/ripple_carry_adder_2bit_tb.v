//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/05/2025 11:32:01 AM
// Design Name: 
// Module Name: ripple_carry_adder_2bit_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ps / 1ps

module ripple_carry_adder_2bit_tb;

    reg [1:0] A, B;
    reg Cin;
    wire [1:0] Sum;
    wire Cout;

    ripple_carry_adder_2bit uut (
        .A(A), .B(B), .Cin(Cin),
        .Sum(Sum), .Cout(Cout)
    );

    integer i, j;
    initial begin
        Cin = 0; 
        for (i = 0; i < 4; i = i + 1) begin
            for (j = 0; j < 4; j = j + 1) begin
                A = i;
                B = j;
                #100;  
                $display("At time %t | A=%b B=%b Cin=%b | Sum=%b Cout=%b",
                         $time, A, B, Cin, Sum, Cout);
            end
        end
        $finish;
    end

endmodule

