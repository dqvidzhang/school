module one_bit_full_adder_tb;
    reg A, B, Cin;
    wire Sum, Cout;

    // Instantiate DUT
    one_bit_full_adder dut (
        .A(A), .B(B), .Cin(Cin),
        .Sum(Sum), .Cout(Cout)
    );

    initial begin
        $display("Time\tA B Cin | Sum Cout");
        $monitor("%t\t%b %b  %b  |  %b    %b", $time, A, B, Cin, Sum, Cout);

        A = 0; B = 0; Cin = 0; #100;
        A = 0; B = 0; Cin = 1; #100;
        A = 0; B = 1; Cin = 0; #100;
        A = 0; B = 1; Cin = 1; #100;
        A = 1; B = 0; Cin = 0; #100;
        A = 1; B = 0; Cin = 1; #100;
        A = 1; B = 1; Cin = 0; #100;
        A = 1; B = 1; Cin = 1; #100;

        $finish;
    end
endmodule
