`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/05/2025 10:15:47 AM
// Design Name: 
// Module Name: ripple_carry_adder_4bit_tb2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ripple_carry_adder_4bit_tb2;

    reg [3:0] A, B;
    reg Cin;
    wire [3:0] Sum;
    wire Cout;

    ripple_carry_adder_4bit uut (
        .A(A), .B(B), .Cin(Cin),
        .Sum(Sum), .Cout(Cout)
    );

    integer i, j;

    initial begin
        Cin = 0;

      
        for (j = 1; j < 16; j = j + 1) begin
            B = j;

           
            for (i = 0; i < 16; i = i + 1) begin
                A = i;
                #10; 
                $display("A=%b B=%b Cin=%b | Sum=%b Cout=%b", A, B, Cin, Sum, Cout);
            end
        end

        $finish;
    end

endmodule

