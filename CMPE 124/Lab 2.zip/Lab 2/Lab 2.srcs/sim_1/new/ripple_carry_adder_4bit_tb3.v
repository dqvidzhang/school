    `timescale 1ns / 1ps
    //////////////////////////////////////////////////////////////////////////////////
    // Company: 
    // Engineer: 
    // 
    // Create Date: 03/05/2025 10:24:39 AM
    // Design Name: 
    // Module Name: ripple_carry_adder_4bit_tb3
    // Project Name: 
    // Target Devices: 
    // Tool Versions: 
    // Description: 
    // 
    // Dependencies: 
    // 
    // Revision:
    // Revision 0.01 - File Created
    // Additional Comments:
    // 
    //////////////////////////////////////////////////////////////////////////////////
    
    
    `timescale 1ns / 1ps
    
    module ripple_carry_adder_4bit_tb3;
    
        reg [3:0] A, B;
        wire [3:0] B_inverted;
        reg Cin;
        wire [3:0] Sum;
        wire Cout;
    
        assign B_inverted = ~B;  
    
        ripple_carry_adder_4bit uut (
            .A(A), .B(B_inverted), .Cin(Cin),
            .Sum(Sum), .Cout(Cout)
        );
    
        integer i, j;
        initial begin
            Cin = 1;  
    
            for (i = 0; i < 16; i = i + 1) begin
                for (j = 0; j < 16; j = j + 1) begin
                    A = i;
                    B = j;  
                    #10; 
                    $display("A=%b B=%b (inverted=%b) Cin=%b | Sum=%b Cout=%b", A, B, B_inverted, Cin, Sum, Cout);
                end
            end
            $finish;
        end
    
    endmodule
    
