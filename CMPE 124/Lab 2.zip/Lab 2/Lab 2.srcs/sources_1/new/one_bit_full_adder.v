`timescale 1ps/1ps

module one_bit_full_adder(
    input A, B, Cin,
    output Sum, Cout
);
    wire AxorB, AandB, AxorBandCin;

    // XOR gates with delay modeled using 2-level gates (e.g. via inverters)
    xor #(10) xor1(AxorB, A, B);              // TINV equivalent for XOR
    xor #(10) xor2(Sum, AxorB, Cin);

    // AND and OR gates with 50ps delay each
    and #(50) and1(AandB, A, B);
    and #(50) and2(AxorBandCin, AxorB, Cin);
    or  #(50) or1(Cout, AandB, AxorBandCin);
endmodule
