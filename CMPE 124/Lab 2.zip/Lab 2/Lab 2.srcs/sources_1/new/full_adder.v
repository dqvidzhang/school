`timescale 1ps / 1ps

module full_adder(
    input A, B, Cin,
    output Sum, Cout
);

    wire not_A, not_B, not_Cin;
    wire o1, o2, o3, o4, o5, o6, o7, TempSum, not_TempSum;

 

    not #(10) (not_A, A);
    not #(10) (not_B, B);
    not #(10) (not_Cin, Cin);

  
    and #(50) (o1, A, not_B);
    and #(50) (o2, not_A, B);
    or  #(50) (TempSum, o1, o2);


    not #(10) (not_TempSum, TempSum);
    and #(50) (o3, TempSum, not_Cin);
    and #(50) (o4, not_TempSum, Cin);
    or  #(50) (Sum, o3, o4);


    and #(50) (o5, A, B);
    and #(50) (o6, B, Cin);
    and #(50) (o7, A, Cin);
    or  #(50) (Cout, o5, o6, o7);

endmodule
