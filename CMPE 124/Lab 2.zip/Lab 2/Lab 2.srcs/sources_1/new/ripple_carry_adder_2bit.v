//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/05/2025 11:30:58 AM
// Design Name: 
// Module Name: ripple_carry_adder_2bit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ps / 1ps

module ripple_carry_adder_2bit(
    input [1:0] A,
    input [1:0] B,
    input Cin,
    output [1:0] Sum,
    output Cout
);

    wire C1;

    full_adder FA0 (
        .A(A[0]), .B(B[0]), .Cin(Cin), 
        .Sum(Sum[0]), .Cout(C1)
    );

    full_adder FA1 (
        .A(A[1]), .B(B[1]), .Cin(C1), 
        .Sum(Sum[1]), .Cout(Cout)
    );

endmodule

