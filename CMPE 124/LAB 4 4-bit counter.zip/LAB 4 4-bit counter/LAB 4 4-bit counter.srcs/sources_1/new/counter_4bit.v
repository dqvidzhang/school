`timescale 1ns / 1ps

module counter_4bit(
    input CLK, RESET, COUNT,
    output [3:0] Q
);

    wire [3:0] next_val, curr_val, adder_out;
    wire cout;

    // Instantiate 4 D Flip-Flops
    d_flip_flop d0 (.D(next_val[0]), .CLK(CLK), .RESET(RESET), .Q(curr_val[0]));
    d_flip_flop d1 (.D(next_val[1]), .CLK(CLK), .RESET(RESET), .Q(curr_val[1]));
    d_flip_flop d2 (.D(next_val[2]), .CLK(CLK), .RESET(RESET), .Q(curr_val[2]));
    d_flip_flop d3 (.D(next_val[3]), .CLK(CLK), .RESET(RESET), .Q(curr_val[3]));

    // Add 1 to current value
    ripple_carry_adder_4bit RCA (.A(curr_val), .B(4'b0001), .Cin(1'b0), .Sum(adder_out), .Cout(cout));

    // MUX for each flip-flop input (stall or increment)
    mux2to1 m0 (.a(curr_val[0]), .b(adder_out[0]), .sel(COUNT), .y(next_val[0]));
    mux2to1 m1 (.a(curr_val[1]), .b(adder_out[1]), .sel(COUNT), .y(next_val[1]));
    mux2to1 m2 (.a(curr_val[2]), .b(adder_out[2]), .sel(COUNT), .y(next_val[2]));
    mux2to1 m3 (.a(curr_val[3]), .b(adder_out[3]), .sel(COUNT), .y(next_val[3]));

    assign Q = curr_val;

endmodule

