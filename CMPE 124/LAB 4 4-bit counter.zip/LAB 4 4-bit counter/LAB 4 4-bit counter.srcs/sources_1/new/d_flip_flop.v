`timescale 1ns / 1ps


module d_flip_flop(
    input D, CLK, RESET,
    output reg Q
);
    always @(posedge CLK or negedge RESET) begin
        if (!RESET)
            Q <= 0;
        else
            Q <= D;
    end
endmodule

