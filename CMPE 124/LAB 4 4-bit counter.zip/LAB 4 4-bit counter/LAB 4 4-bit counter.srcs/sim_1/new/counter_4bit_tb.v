`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/16/2025 09:02:27 AM
// Design Name: 
// Module Name: counter_4bit_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module counter_4bit_tb;

    reg CLK, RESET, COUNT;
    wire [3:0] Q;

    counter_4bit uut (.CLK(CLK), .RESET(RESET), .COUNT(COUNT), .Q(Q));

    always #5 CLK = ~CLK;

    initial begin
        CLK = 0; RESET = 0; COUNT = 0;
        #10 RESET = 1;

        // Counting Mode
        COUNT = 1;
        #80;

        // Stall Mode
        COUNT = 0;
        #20;

        // Resume Count
        COUNT = 1;
        #40;

        // Reset
        RESET = 0;
        #10 RESET = 1;

        #30 $finish;
    end

    initial begin
        $monitor("Time = %0t | CLK = %b | RESET = %b | COUNT = %b | Q = %b", $time, CLK, RESET, COUNT, Q);
    end

endmodule
