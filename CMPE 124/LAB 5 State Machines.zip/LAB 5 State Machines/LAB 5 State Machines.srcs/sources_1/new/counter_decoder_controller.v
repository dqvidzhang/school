module counter_decoder_controller (
    input clk,
    input reset,        // active-low synchronous reset
    input Stop,
    output reg [2:0] CountOut,
    output reg Out
);

    // Sequential logic: update state on rising clock edge
    always @(posedge clk) begin
        if (!reset)
            CountOut <= 3'b000;
        else if (Stop)
            CountOut <= CountOut + 1;
    end

    // Combinational logic: determine output based on state
    always @(*) begin
        if (CountOut == 3'b010)  // S2
            Out = 1;
        else
            Out = 0;
    end

endmodule
