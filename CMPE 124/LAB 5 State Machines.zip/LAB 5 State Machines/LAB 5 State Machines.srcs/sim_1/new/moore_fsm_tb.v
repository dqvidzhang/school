module moore_fsm_tb;
    reg clk = 0;
    reg reset_n = 0;
    reg in = 0;
    wire [2:0] out;

    // Instantiate FSM
    moore_fsm dut (
        .clk(clk),
        .reset_n(reset_n),
        .in(in),
        .out(out)
    );

    // Clock generation (10ns period)
    always #5 clk = ~clk;

    initial begin
        $display("Time\tIn\tOut");
        $monitor("%0t | in = %b | out = %d", $time, in, out);

        // Initial reset
        reset_n = 0;
        in = 0;
        #10;

        reset_n = 1; // Release reset
        #10;

        in = 1; #10; // S0 ? S1
        in = 1; #10; // S1 ? S2
        in = 1; #10; // S2 ? S3
        in = 0; #10; // S3 ? S3 (should hold)
        in = 1; #10; // S3 ? S0
        in = 0; #10; // S0 ? S0 (hold)
        in = 1; #10; // S0 ? S1
        in = 0; #10; // S1 ? S1 (hold)

        // Optional: mid-sequence reset test
        reset_n = 0; #10;
        reset_n = 1; #10; // Back to S0

        $finish;
    end
endmodule
