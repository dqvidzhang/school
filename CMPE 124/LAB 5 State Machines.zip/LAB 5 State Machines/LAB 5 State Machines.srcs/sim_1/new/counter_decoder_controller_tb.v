`timescale 1ns / 1ps

module counter_decoder_controller_tb;

    reg clk = 0;
    reg reset = 0;
    reg Stop = 0;
    wire [2:0] CountOut;
    wire Out;

    // Instantiate the DUT (Device Under Test)
    counter_decoder_controller dut (
        .clk(clk),
        .reset(reset),
        .Stop(Stop),
        .CountOut(CountOut),
        .Out(Out)
    );

    // Clock generation: 10ns period
    always #5 clk = ~clk;

    initial begin
        $display("Time\tReset\tStop\tCountOut\tOut");
        $monitor("%0t\t%b\t%b\t%b\t\t%b", $time, reset, Stop, CountOut, Out);

        // Initial conditions
        reset = 0;
        Stop = 0;

        // Hold reset for 2 cycles
        #10;
        reset = 1;

        // Cycle Stop = 1 for 8 clock cycles to walk through states
        Stop = 1;
        repeat (10) #10;  // Wait 10 cycles

        // Deactivate Stop
        Stop = 0;
        #20;

        $finish;
    end

endmodule
