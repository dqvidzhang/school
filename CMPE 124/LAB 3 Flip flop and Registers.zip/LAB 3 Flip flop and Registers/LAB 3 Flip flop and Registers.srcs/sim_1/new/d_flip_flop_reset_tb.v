`timescale 1ns / 1ps

module d_flip_flop_reset_tb;

    reg D, CLK, RESET_N;
    wire Q, Qn;

   
    d_flip_flop_reset uut (
        .D(D),
        .CLK(CLK),
        .RESET_N(RESET_N),
        .Q(Q),
        .Qn(Qn)
    );

    
    always #5 CLK = ~CLK; 

    initial begin
        
        CLK = 0;
        RESET_N = 0; 
        D = 0;

        #10 RESET_N = 1; 

        
        #10 D = 1;
        #10 D = 0;
        #10 D = 1;
        #10 RESET_N = 0; 
        #10 RESET_N = 1; 
        #10 D = 0;
        #10 D = 1;
        #10 D = 0;
        
        #20 $finish; 
    end

    initial begin
        $monitor("Time = %0t | D = %b | CLK = %b | RESET_N = %b | Q = %b | Qn = %b",
                 $time, D, CLK, RESET_N, Q, Qn);
    end

endmodule
