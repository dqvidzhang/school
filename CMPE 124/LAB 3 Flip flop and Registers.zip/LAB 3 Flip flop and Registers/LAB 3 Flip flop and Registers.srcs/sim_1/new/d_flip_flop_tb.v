`timescale 1ns / 1ps

module d_flip_flop_tb;

    reg D, CLK;
    wire Q, Qn;

    d_flip_flop uut (
        .D(D),
        .CLK(CLK),
        .Q(Q),
        .Qn(Qn)
    );

    initial begin
        CLK = 0;
        D = 0;
        

        #10 D = 1;
        #10 CLK = 1;
        #10 CLK = 0;
        
        #10 D = 0; 
        #10 CLK = 1; 
        #10 CLK = 0;
        
        #10 D = 1;
        #10 CLK = 1;
        #10 CLK = 0;
        
        #10 D = 0; 
        #10 CLK = 1;
        #10 CLK = 0;
        
        #20 $finish; 
    end

    initial begin
        $monitor("Time=%t | CLK=%b | D=%b | Q=%b | Qn=%b", $time, CLK, D, Q, Qn);
    end

endmodule
