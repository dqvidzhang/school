`timescale 1ns / 1ps

module bhv_one_bit_tb();

    reg D, CLK, Select;
    wire Q, Qn;

    // Instantiate the one-bit register
    bhv_one_bit uut (
        .D(D), 
        .CLK(CLK), 
        .Select(Select), 
        .Q(Q), 
        .Qn(Qn)
    );

    // Generate Clock Signal
    always #5 CLK = ~CLK;  // Toggle CLK every 5ns (Clock Period = 10ns)

    initial begin
        // Initialize Inputs
        CLK = 0;
        D = 0;
        Select = 0;

        #10 Select = 1; D = 1;   // Store 1
        #10 Select = 0;          // Hold previous value
        #10 Select = 1; D = 0;   // Store 0
        #10 Select = 1; D = 1;   // Store 1
        #10 Select = 0;          // Hold previous value
        #10 Select = 1; D = 0;   // Store 0
        
        #20 $finish;  // End simulation
    end

    // Monitor and Display Output
    initial begin
        $monitor("Time = %t | D = %b | CLK = %b | Select = %b | Q = %b | Qn = %b", 
                 $time, D, CLK, Select, Q, Qn);
    end

endmodule
