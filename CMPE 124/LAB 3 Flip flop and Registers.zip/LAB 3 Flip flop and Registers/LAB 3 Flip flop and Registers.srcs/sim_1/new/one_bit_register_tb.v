`timescale 1ns / 1ps

module one_bit_register_tb();

    reg D, CLK, Select;
    wire Q, Qn;

    one_bit_register uut (
        .D(D), 
        .CLK(CLK), 
        .Select(Select), 
        .Q(Q), 
        .Qn(Qn)
    );

    always #5 CLK = ~CLK; 

    initial begin
       
        CLK = 0;
        D = 0;
        Select = 0;

        
        #10 Select = 1; D = 1;   
        #10 Select = 0;          
        #10 Select = 1; D = 0;   
        #10 Select = 1; D = 1;   
        #10 Select = 0;          
        #10 Select = 1; D = 0;   
        
        #20 $finish;  
    end

    initial begin
        $monitor("Time = %t | D = %b | CLK = %b | Select = %b | Q = %b | Qn = %b", 
                 $time, D, CLK, Select, Q, Qn);
    end

endmodule
