`timescale 1ns / 1ps

module bhv_one_bit (
    input D, CLK, Select,
    output reg Q, Qn
);

    always @(posedge CLK) begin
        if (Select) begin
            Q <= D;
            Qn <= ~D;
        end
    end

endmodule
