`timescale 1ns / 1ps

module d_flip_flop_reset(
    input D, CLK, RESET_N, 
    output reg Q, Qn
);

    always @(posedge CLK or negedge RESET_N) begin
        if (!RESET_N) begin  
            Q <= 0;
            Qn <= 1;
        end else begin
            Q <= D;
            Qn <= ~D;
        end
    end

endmodule
