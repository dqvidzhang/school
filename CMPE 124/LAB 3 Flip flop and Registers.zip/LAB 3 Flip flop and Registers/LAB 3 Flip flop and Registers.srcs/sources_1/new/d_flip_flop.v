`timescale 1ns / 1ps

module nand_gate(output c, input a, input b);
    assign c = ~(a & b);
endmodule

module not_gate(output f, input e);
    nand_gate n1(f, e, e);
endmodule

module tri_state_buffer(output out, input in, input enable);
    assign out = enable ? in : out;
endmodule

module d_flip_flop(
    input D, CLK,
    output Q, Qn
);

    wire Dn, S, R, Qa, Qb;

    not_gate not1(Dn, D);

    nand_gate nand1(S, D, CLK); 
    nand_gate nand2(R, Dn, CLK);

    nand_gate nand3(Qa, S, Qb);
    nand_gate nand4(Qb, R, Qa);

    assign Q = Qa;
    assign Qn = Qb;

endmodule

module one_bit_register(
    input D, CLK, Select,
    output Q, Qn
);

    wire clk_enable, D_enable;

 
    assign clk_enable = CLK & Select;

    tri_state_buffer tri_buf(D_enable, D, Select);

    d_flip_flop dff (.D(D_enable), .CLK(clk_enable), .Q(Q), .Qn(Qn));

endmodule
