    module top_basys3 (
    input  wire [15:0] sw,   
    output wire [15:0] led   
);
    wire [3:0] A  = sw[3:0];     
    wire [3:0] B  = sw[7:4];     
    wire       Ci = sw[8];       

    wire [3:0] S;
    wire Co, PG, GG;

    CLA4 u (.A(A), .B(B), .Ci(Ci), .S(S), .Co(Co), .PG(PG), .GG(GG));

    assign led[3:0] = S;   //Sum
    assign led[4]   = Co;  //Carry out
    assign led[5]   = PG;  //GP
    assign led[6]   = GG;  //GG
    assign led[15:7]= 9'b0;
endmodule