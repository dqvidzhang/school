module CLA4 (
    input  wire [3:0] A,
    input  wire [3:0] B,
    input  wire       Ci,
    output wire [3:0] S,
    output wire       Co,
    output wire       PG,
    output wire       GG
);
    wire [3:0] P, G;
    wire [3:1] C;   


    CLALogic Ucla (.G(G), .P(P), .Ci(Ci), .C(C), .Co(Co), .PG(PG), .GG(GG));

 
    GPFullAdder U0 (.Ai(A[0]), .Bi(B[0]), .Cin(Ci),  .G(G[0]), .P(P[0]), .Sum(S[0]));
    GPFullAdder U1 (.Ai(A[1]), .Bi(B[1]), .Cin(C[1]), .G(G[1]), .P(P[1]), .Sum(S[1]));
    GPFullAdder U2 (.Ai(A[2]), .Bi(B[2]), .Cin(C[2]), .G(G[2]), .P(P[2]), .Sum(S[2]));
    GPFullAdder U3 (.Ai(A[3]), .Bi(B[3]), .Cin(C[3]), .G(G[3]), .P(P[3]), .Sum(S[3]));
endmodule