module GPFullAdder (
    input  wire Ai, Bi, Cin,
    output wire G,   // generate
    output wire P,   // propagate
    output wire Sum
);
    assign P   = Ai ^ Bi;     // propagate
    assign G   = Ai & Bi;     // generate
    assign Sum = P  ^ Cin;    // Ai ^ Bi ^ Cin
endmodule

