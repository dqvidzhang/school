// ---------- 4-bit CLA carry block ----------
module CLALogic (
    input  wire [3:0] G,
    input  wire [3:0] P,
    input  wire       Ci,
    output wire [3:1] C,   
    output wire       Co,  
    output wire       PG, 
    output wire       GG   
);
    assign C[1] = G[0] | (P[0] & Ci);
    assign C[2] = G[1] | (P[1] & G[0]) | (P[1] & P[0] & Ci);
    assign C[3] = G[2] | (P[2] & G[1]) | (P[2] & P[1] & G[0]) | (P[2] & P[1] & P[0] & Ci);

    assign Co   = G[3] | (P[3] & G[2]) | (P[3] & P[2] & G[1])
                        | (P[3] & P[2] & P[1] & G[0])
                        | (P[3] & P[2] & P[1] & P[0] & Ci);

    assign PG   = P[3] & P[2] & P[1] & P[0];
    assign GG   = G[3] | (P[3] & G[2]) | (P[3] & P[2] & G[1]) | (P[3] & P[2] & P[1] & G[0]);
endmodule



