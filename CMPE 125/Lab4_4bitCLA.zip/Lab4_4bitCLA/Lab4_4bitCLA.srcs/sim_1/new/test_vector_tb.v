`timescale 1ns/1ps
module test_vector_tb;
  reg  [3:0] A, B;
  reg        Ci;
  wire [3:0] S;
  wire       Co, PG, GG;

  // DUT
  CLA4 dut (.A(A), .B(B), .Ci(Ci), .S(S), .Co(Co), .PG(PG), .GG(GG));

  integer fh, r, line, errors;
  reg [15:0] vec;  // {A[3:0], B[3:0], Ci, Sexp[3:0], Coexp, PGexp, GGexp}

  initial begin
    errors = 0;
    line   = 0;

    fh = $fopen("C:/Users/David/Lab4_4bitCLA/Lab4_4bitCLA.srcs/sim_1/new/test_vector.tv","r");
    if (fh == 0) begin
      $display("FATAL: can't open test_vector.tv");
      $finish;
    end


    while (!$feof(fh)) begin
      r = $fscanf(fh, "%b\n", vec);   
      if (r == 1) begin
        line = line + 1;
        {A, B, Ci} = vec[15:7];  
        #1;                     

        if ({S, Co, PG, GG} !== vec[6:0]) begin
          $display("Line%0d FAIL: A=%b B=%b Ci=%b  got S=%b Co=%b PG=%b GG=%b  exp=%b",
                   line, A, B, Ci, S, Co, PG, GG, vec[6:0]);
          errors = errors + 1;
        end else begin
          $display("Line%0d PASS: A=%b B=%b Ci=%b  S=%b Co=%b PG=%b GG=%b",
                   line, A, B, Ci, S, Co, PG, GG);
        end
      end
  
    end
    $fclose(fh);

    if (line == 0) $display("No vectors read - check file content/format.");
    else if (errors == 0) $display("PASS: All %0d vectors matched.", line);
    else                  $display("FAIL: %0d of %0d vectors mismatched.", errors, line);

    $finish;
  end
endmodule
