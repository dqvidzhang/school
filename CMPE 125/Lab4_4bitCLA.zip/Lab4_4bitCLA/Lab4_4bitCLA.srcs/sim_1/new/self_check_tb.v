`timescale 1ns/1ps
module self_check_tb;
  reg  [3:0] A, B;
  reg        Ci;
  wire [3:0] S;
  wire       Co, PG, GG;


  CLA4 dut(.A(A), .B(B), .Ci(Ci), .S(S), .Co(Co), .PG(PG), .GG(GG));

  integer errors, total;
  reg pg_exp, gg_exp;

  initial begin
    errors = 0;

    // 1) 5 + 3 + 0 = 8
    A=4'h5; B=4'h3; Ci=1'b0; #1;
    total = 5+3+0;
    pg_exp = &(A ^ B);
    gg_exp = ((5+3) >= 16);
    if ({Co,S} !== total[4:0]) begin $display("Case1 sum mismatch"); errors=errors+1; end
    if (PG !== pg_exp) begin $display("Case1 PG mismatch"); errors=errors+1; end
    if (GG !== gg_exp) begin $display("Case1 GG mismatch"); errors=errors+1; end

    // 2) Propagate case (PG=1): A^B=1111
    A=4'hA; B=4'h5; Ci=1'b0; #1;
    total = 10+5+0;
    pg_exp = 1'b1; gg_exp = 1'b0;
    if ({Co,S} !== total[4:0]) begin $display("Case2 sum mismatch"); errors=errors+1; end
    if (PG !== pg_exp) begin $display("Case2 PG mismatch"); errors=errors+1; end
    if (GG !== gg_exp) begin $display("Case2 GG mismatch"); errors=errors+1; end

    // 3) Generate case (GG=1): 8 + 8 = 16
    A=4'h8; B=4'h8; Ci=1'b0; #1;
    total = 8+8+0;
    pg_exp = &(A ^ B);
    gg_exp = 1'b1;
    if ({Co,S} !== total[4:0]) begin $display("Case3 sum mismatch"); errors=errors+1; end
    if (PG !== pg_exp) begin $display("Case3 PG mismatch"); errors=errors+1; end
    if (GG !== gg_exp) begin $display("Case3 GG mismatch"); errors=errors+1; end

    // 4) 15 + 1 + 1 = 17
    A=4'hF; B=4'h1; Ci=1'b1; #1;
    total = 15+1+1;
    pg_exp = &(A ^ B);
    gg_exp = ((15+1) >= 16);
    if ({Co,S} !== total[4:0]) begin $display("Case4 sum mismatch"); errors=errors+1; end
    if (PG !== pg_exp) begin $display("Case4 PG mismatch"); errors=errors+1; end
    if (GG !== gg_exp) begin $display("Case4 GG mismatch"); errors=errors+1; end

    if (errors==0) $display("PASS: 4/4 cases matched.");
    else           $display("FAIL: %0d mismatches.", errors);

    $finish;
  end
endmodule
