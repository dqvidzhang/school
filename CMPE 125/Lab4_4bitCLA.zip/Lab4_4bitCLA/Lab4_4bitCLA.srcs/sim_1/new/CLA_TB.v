`timescale 1ns/1ps

module tb_CLA4;
  // DUT inputs
  reg  [3:0] A;
  reg  [3:0] B;
  reg        Ci;

  // DUT outputs
  wire [3:0] S;
  wire       Co, PG, GG;

  // Device under test
  CLA4 dut (
    .A(A), .B(B), .Ci(Ci),
    .S(S), .Co(Co), .PG(PG), .GG(GG)
  );

  integer a, b, ci;
  integer errors;
  integer total;
  reg pg_exp, gg_exp;

  initial begin
    errors = 0;

    // Exhaustive sweep: A,B in 0..15, Ci in {0,1}
    for (a = 0; a < 16; a = a + 1) begin
      for (b = 0; b < 16; b = b + 1) begin
        for (ci = 0; ci < 2; ci = ci + 1) begin
          A  = a[3:0];
          B  = b[3:0];
          Ci = ci[0:0];

          #1; // allow combinational settle

          // Expected arithmetic
          total = a + b + ci;

          if ({Co, S} !== total[4:0]) begin
            $display("SUM/CO MISMATCH: A=%h B=%h Ci=%0d  -> got Co=%b S=%b  exp Co=%b S=%b",
                      A, B, Ci, Co, S, total[4], total[3:0]);
            errors = errors + 1;
          end

          // Expected group signals
          pg_exp = &(A ^ B);              // all bits propagate
          gg_exp = ((a + b) >= 16);       // carry out with Ci=0

          if (PG !== pg_exp) begin
            $display("PG MISMATCH: A=%h B=%h  -> got PG=%b exp PG=%b", A, B, PG, pg_exp);
            errors = errors + 1;
          end
          if (GG !== gg_exp) begin
            $display("GG MISMATCH: A=%h B=%h  -> got GG=%b exp GG=%b", A, B, GG, gg_exp);
            errors = errors + 1;
          end
        end
      end
    end

    if (errors == 0) begin
      $display("PASS: All 512 cases matched.");
    end else begin
      $display("FAIL: %0d mismatches.", errors);
      $fatal(1);
    end
    $finish;
  end
endmodule
