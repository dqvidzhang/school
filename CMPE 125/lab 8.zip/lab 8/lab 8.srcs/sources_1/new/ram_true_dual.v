// ram_true_dual.v
module ram_true_dual #
(
  parameter ADDR_WIDTH = 4,   // use 7 for 128 x 8 in the final lab
  parameter DATA_WIDTH = 8
)
(
  input  wire                     clk,

  // Port A
  input  wire                     we_a,
  input  wire [ADDR_WIDTH-1:0]    addr_a,
  input  wire [DATA_WIDTH-1:0]    d_a,
  output wire [DATA_WIDTH-1:0]    q_a,

  // Port B
  input  wire                     we_b,
  input  wire [ADDR_WIDTH-1:0]    addr_b,
  input  wire [DATA_WIDTH-1:0]    d_b,
  output wire [DATA_WIDTH-1:0]    q_b
);

  reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

  // asynchronous reads (like the single-port example)
  assign q_a = mem[addr_a];
  assign q_b = mem[addr_b];

  // synchronous writes on shared clock
  always @(posedge clk) begin
    if (we_a)
      mem[addr_a] <= d_a;
    if (we_b)
      mem[addr_b] <= d_b;
  end

endmodule
