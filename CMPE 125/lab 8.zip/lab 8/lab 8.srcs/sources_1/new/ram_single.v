module ram_single #
(
  parameter ADDR_WIDTH = 7,   // 2^7 = 128 locations
  parameter DATA_WIDTH = 8
)
(
  input  wire                     clk,
  input  wire                     we,      // write enable
  input  wire [ADDR_WIDTH-1:0]    a,
  input  wire [DATA_WIDTH-1:0]    d,
  output wire [DATA_WIDTH-1:0]    q
);

  reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

  // async read
  assign q = mem[a];

  // sync write
  always @(posedge clk) begin
    if (we)
      mem[a] <= d;
  end

endmodule
