module ram_dual_two_clk #
(
  parameter ADDR_WIDTH = 7,
  parameter DATA_WIDTH = 8
)
(
  // Port A
  input  wire                     clk1,
  input  wire                     we1,
  input  wire [ADDR_WIDTH-1:0]    a1,
  input  wire [DATA_WIDTH-1:0]    d1,
  output wire [DATA_WIDTH-1:0]    q1,

  // Port B
  input  wire                     clk2,
  input  wire                     we2,
  input  wire [ADDR_WIDTH-1:0]    a2,
  input  wire [DATA_WIDTH-1:0]    d2,
  output wire [DATA_WIDTH-1:0]    q2
);

  reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

  // async reads for both ports
  assign q1 = mem[a1];
  assign q2 = mem[a2];

  // Port A: sync write on clk1
  always @(posedge clk1) begin
    if (we1)
      mem[a1] <= d1;
  end

  // Port B: sync write on clk2
  always @(posedge clk2) begin
    if (we2)
      mem[a2] <= d2;
  end

endmodule
