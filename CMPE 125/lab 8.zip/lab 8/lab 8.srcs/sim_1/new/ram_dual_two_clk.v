`timescale 1ns/1ps

module ram_dual_two_clk_tb;

  localparam ADDR_WIDTH = 4;   // 16 locations
  localparam DATA_WIDTH = 8;
  localparam DEPTH      = 1 << ADDR_WIDTH;

  reg                     clk1, clk2;
  reg                     we1, we2;
  reg  [ADDR_WIDTH-1:0]   a1, a2;
  reg  [DATA_WIDTH-1:0]   d1, d2;
  wire [DATA_WIDTH-1:0]   q1, q2;

  integer i;
  integer errors;
  reg [DATA_WIDTH-1:0] expected;

  // DUT
  ram_dual_two_clk #(
    .ADDR_WIDTH(ADDR_WIDTH),
    .DATA_WIDTH(DATA_WIDTH)
  ) dut (
    .clk1(clk1),
    .we1(we1),
    .a1 (a1),
    .d1 (d1),
    .q1 (q1),
    .clk2(clk2),
    .we2(we2),
    .a2 (a2),
    .d2 (d2),
    .q2 (q2)
  );

  // Two independent clocks
  initial clk1 = 0;
  always #5 clk1 = ~clk1;     // 10 ns period

  initial clk2 = 0;
  always #7 clk2 = ~clk2;     // 14 ns period (just to be different)

  initial begin
    errors = 0;
    we1    = 0;
    we2    = 0;
    a1     = 0;
    a2     = 0;
    d1     = 0;
    d2     = 0;

    // --- Write even addresses using Port 1 ---
    @(posedge clk1);
    for (i = 0; i < DEPTH; i = i + 2) begin
      a1  <= i[ADDR_WIDTH-1:0];
      d1  <= 8'hA0 + i[7:0];
      we1 <= 1;
      @(posedge clk1);
    end
    we1 <= 0;

    // --- Write odd addresses using Port 2 ---
    @(posedge clk2);
    for (i = 1; i < DEPTH; i = i + 2) begin
      a2  <= i[ADDR_WIDTH-1:0];
      d2  <= 8'h50 + i[7:0];
      we2 <= 1;
      @(posedge clk2);
    end
    we2 <= 0;

    // --- Read back even addresses on Port 1 ---
    for (i = 0; i < DEPTH; i = i + 2) begin
      a1 <= i[ADDR_WIDTH-1:0];
      #1;  // async read
      expected = 8'hA0 + i[7:0];
      if (q1 !== expected) begin
        $display("ERROR DUAL P1: addr %0d expected %0h got %0h",
                  i, expected, q1);
        errors = errors + 1;
      end
      @(posedge clk1);
    end

    // --- Read back odd addresses on Port 2 ---
    for (i = 1; i < DEPTH; i = i + 2) begin
      a2 <= i[ADDR_WIDTH-1:0];
      #1;  // async read
      expected = 8'h50 + i[7:0];
      if (q2 !== expected) begin
        $display("ERROR DUAL P2: addr %0d expected %0h got %0h",
                  i, expected, q2);
        errors = errors + 1;
      end
      @(posedge clk2);
    end

    if (errors == 0)
      $display("ram_dual_two_clk_tb: ALL TESTS PASSED");
    else
      $display("ram_dual_two_clk_tb: %0d ERRORS", errors);

    $finish;
  end

endmodule
