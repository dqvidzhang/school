`timescale 1ns/1ps

module ram_single_tb;

  localparam ADDR_WIDTH = 4;   // 16 locations for quick sim
  localparam DATA_WIDTH = 8;
  localparam DEPTH      = 1 << ADDR_WIDTH;

  reg                     clk;
  reg                     we;
  reg  [ADDR_WIDTH-1:0]   a;
  reg  [DATA_WIDTH-1:0]   d;
  wire [DATA_WIDTH-1:0]   q;

  integer i;
  integer errors;
  reg [DATA_WIDTH-1:0] expected;

  // DUT
  ram_single #(
    .ADDR_WIDTH(ADDR_WIDTH),
    .DATA_WIDTH(DATA_WIDTH)
  ) dut (
    .clk(clk),
    .we(we),
    .a(a),
    .d(d),
    .q(q)
  );

  // Clock: 10 ns period
  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    errors = 0;
    we     = 0;
    a      = 0;
    d      = 0;

    // WRITE PHASE: write pattern 0xA0 + address
    @(posedge clk);
    for (i = 0; i < DEPTH; i = i + 1) begin
      a  <= i[ADDR_WIDTH-1:0];
      d  <= 8'hA0 + i[7:0];
      we <= 1;
      @(posedge clk);
    end
    we <= 0;

    // READ PHASE: read back and compare
    for (i = 0; i < DEPTH; i = i + 1) begin
      a <= i[ADDR_WIDTH-1:0];
      #1;  // async read, data appears quickly
      expected = 8'hA0 + i[7:0];
      if (q !== expected) begin
        $display("ERROR SINGLE: addr %0d expected %0h got %0h",
                  i, expected, q);
        errors = errors + 1;
      end
    end

    if (errors == 0)
      $display("ram_single_tb: ALL TESTS PASSED");
    else
      $display("ram_single_tb: %0d ERRORS", errors);

    $finish;
  end

endmodule
