// ram_true_dual_tb.v
`timescale 1ns/1ps

module ram_true_dual_tb;

  localparam ADDR_WIDTH = 4;   // 16 locations for quick sim
  localparam DATA_WIDTH = 8;
  localparam DEPTH      = 1 << ADDR_WIDTH;

  reg                     clk;
  reg                     we_a, we_b;
  reg  [ADDR_WIDTH-1:0]   addr_a, addr_b;
  reg  [DATA_WIDTH-1:0]   d_a, d_b;
  wire [DATA_WIDTH-1:0]   q_a, q_b;

  integer i;
  integer errors;
  reg [DATA_WIDTH-1:0] expected;

  // DUT
  ram_true_dual #(
    .ADDR_WIDTH(ADDR_WIDTH),
    .DATA_WIDTH(DATA_WIDTH)
  ) dut (
    .clk   (clk),
    .we_a  (we_a),
    .addr_a(addr_a),
    .d_a   (d_a),
    .q_a   (q_a),
    .we_b  (we_b),
    .addr_b(addr_b),
    .d_b   (d_b),
    .q_b   (q_b)
  );

  // 10 ns clock
  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    errors = 0;
    we_a   = 0;
    we_b   = 0;
    addr_a = 0;
    addr_b = 0;
    d_a    = 0;
    d_b    = 0;

    // --------- Write phase: fill memory via Port A ----------
    @(posedge clk);
    for (i = 0; i < DEPTH; i = i + 1) begin
      addr_a = i[ADDR_WIDTH-1:0];
      d_a    = 8'hC0 + i[7:0];
      we_a   = 1;
      @(posedge clk);          // write happens here
    end
    we_a = 0;

    // --------- Read-back phase: read via Port B (async read) ----------
    for (i = 0; i < DEPTH; i = i + 1) begin
      addr_b = i[ADDR_WIDTH-1:0];
      we_b   = 0;
      #1;                       // allow async read to settle
      expected = 8'hC0 + i[7:0];
      if (q_b !== expected) begin
        $display("ERROR TRUE DUAL: addr %0d expected %0h got %0h",
                 i, expected, q_b);
        errors = errors + 1;
      end
      @(posedge clk);
    end

    // --------- Extra test: both ports write different addresses ----------
    addr_a = 0; d_a = 8'hAA; we_a = 1;
    addr_b = 1; d_b = 8'hBB; we_b = 1;
    @(posedge clk);            // both writes happen on same edge
    we_a = 0; we_b = 0;

    // Read them back on both ports
    addr_a = 0;
    addr_b = 1;
    #1;                         // async read
    if (q_a !== 8'hAA) begin
      $display("ERROR TRUE DUAL extra: addr 0 expected AA got %0h", q_a);
      errors = errors + 1;
    end
    if (q_b !== 8'hBB) begin
      $display("ERROR TRUE DUAL extra: addr 1 expected BB got %0h", q_b);
      errors = errors + 1;
    end

    // --------- Finish ----------
    if (errors == 0)
      $display("ram_true_dual_tb: ALL TESTS PASSED");
    else
      $display("ram_true_dual_tb: %0d ERRORS", errors);

    $finish;
  end

endmodule
