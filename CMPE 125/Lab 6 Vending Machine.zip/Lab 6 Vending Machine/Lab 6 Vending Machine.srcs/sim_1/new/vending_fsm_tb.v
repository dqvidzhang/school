`timescale 1ns/1ps
module vending_fsm_tb;


  reg  clk, rst, n, d, q;   
  wire V, R5, R10, R20;     


  vending_fsm_25 dut (
    .clk(clk), .rst(rst), .n(n), .d(d), .q(q),
    .V(V), .R5(R5), .R10(R10), .R20(R20)
  );


  initial clk = 1'b0;
  always #5 clk = ~clk;


  localparam S0=3'd0, S5=3'd1, S10=3'd2, S15=3'd3, S20=3'd4;
  reg [2:0] ref_state, ref_next;


  function [6:0] ref_step_25;
    input [2:0] st;
    input       rst_i, n_i, d_i, q_i;
    integer credit, add, sum, change;
    reg [2:0] ns;
    reg v, r5, r10, r20;
    begin
      case (st)
        S0:  credit = 0;
        S5:  credit = 5;
        S10: credit = 10;
        S15: credit = 15;
        S20: credit = 20;
        default: credit = 0;
      endcase

   
      if (rst_i) begin
        v=0; r5=0; r10=0; r20=0;
        case (st)
          S5:   r5  = 1;
          S10:  r10 = 1;
          S15: begin r10 = 1; r5 = 1; end
          S20:  r20 = 1;
        endcase
        ns = S0;
      end else begin
        add = (n_i?5:0) + (d_i?10:0) + (q_i?25:0); 
        sum = credit + add;

        v=0; r5=0; r10=0; r20=0; ns=st;

        if (sum >= 25) begin
          v = 1;
          change = sum - 25;   
         
          if (change >= 20)        r20 = 1;
          else if (change == 15) begin r10 = 1; r5 = 1; end
          else if (change == 10)   r10 = 1;
          else if (change == 5)    r5  = 1;
          ns = S0;
        end else begin
          case (sum)
            0:  ns=S0;  5:  ns=S5;  10: ns=S10;  15: ns=S15;  20: ns=S20;
            default: ns=S0; 
          endcase
        end
      end
      ref_step_25 = {v,r5,r10,r20,ns};
    end
  endfunction
  // ----------------------------------------------------------------

  integer fh, r, line, errors, passes;
  reg [3:0] RNDQ;                 
  reg vexp, r5exp, r10exp, r20exp;

  initial begin
    rst=1; n=0; d=0; q=0; line=0; errors=0; passes=0; ref_state=S0;
    repeat (2) @(posedge clk);
    rst=0;

    fh = $fopen("vend_vectors.tv","r");
    if (fh==0) $fatal(1,"can't open vend_vectors.tv");

    while (!$feof(fh)) begin
      r = $fscanf(fh, "%4b\n", RNDQ);       
      if (r == 1) begin
        @(negedge clk);

        rst = RNDQ[3];  // R
        n   = RNDQ[2];  // N
        d   = RNDQ[1];  // D
        q   = RNDQ[0];  // Q

        {vexp,r5exp,r10exp,r20exp,ref_next} = ref_step_25(ref_state, rst, n, d, q);

        #1;
        if (V!==vexp || R5!==r5exp || R10!==r10exp || R20!==r20exp) begin
          $display("Line%0d FAIL: RNDQ=%b  -> V/R5/R10/R20 = %b%b%b%b  exp=%b%b%b%b  state=%0d",
                   line+1, RNDQ, V,R5,R10,R20, vexp,r5exp,r10exp,r20exp, ref_state);
          errors = errors + 1;
        end else begin
          $display("Line%0d PASS: RNDQ=%b  V/R5/R10/R20=%b%b%b%b  next=%0d",
                   line+1, RNDQ, V,R5,R10,R20, ref_next);
          passes = passes + 1;
        end

        @(posedge clk);
        ref_state = ref_next;
        
        rst=0; n=0; d=0; q=0;
        line = line + 1;
      end
    end

    $fclose(fh);
    $display("SUMMARY: lines=%0d  pass=%0d  fail=%0d", line, passes, errors);
    $finish;
  end
endmodule
