`timescale 1ns/1ps
module vending_fsm_25 (
  input  wire clk,
  input  wire rst,     
  input  wire n,       // nickel
  input  wire d,       // dime
  input  wire q,       // quarter
  output reg  V,       // dispense drink 
  output reg  R5,      // return nickel 
  output reg  R10,     // return dime 
  output reg  R20      // return two dimes 
);
  // Credit states: 0,5,10,15,20
  localparam S0  = 3'd0,
             S5  = 3'd1,
             S10 = 3'd2,
             S15 = 3'd3,
             S20 = 3'd4;

  reg [2:0] state, next;

 
  reg  [5:0] credit, add, sum, change;


  always @* begin
    
    case (state)
      S0:  credit = 6'd0;
      S5:  credit = 6'd5;
      S10: credit = 6'd10;
      S15: credit = 6'd15;
      S20: credit = 6'd20;
      default: credit = 6'd0;
    endcase

    add = (n ? 6'd5  : 6'd0) +
          (d ? 6'd10 : 6'd0) +
          (q ? 6'd25 : 6'd0);

  
    V   = 1'b0;
    R5  = 1'b0;
    R10 = 1'b0;
    R20 = 1'b0;
    next = state;

    if (rst) begin
      
      case (state)
        S5:   R5  = 1'b1;
        S10:  R10 = 1'b1;
        S15: begin R10 = 1'b1; R5 = 1'b1; end
        S20:  R20 = 1'b1;
        default: ; 
      endcase
      next = S0;
    end else begin
      sum = credit + add;

      if (sum >= 6'd25) begin
 
        V = 1'b1;
        change = sum - 6'd25;

        if (change >= 6'd20)       R20 = 1'b1;             
        else if (change == 6'd15) begin R10 = 1'b1; R5 = 1'b1; end
        else if (change == 6'd10)  R10 = 1'b1;
        else if (change == 6'd5)   R5  = 1'b1;

        next = S0;  
      end else begin
       
        case (sum)
          6'd0:  next = S0;
          6'd5:  next = S5;
          6'd10: next = S10;
          6'd15: next = S15;
          6'd20: next = S20;
          default: next = S0;  
        endcase
      end
    end
  end


  always @(posedge clk) begin
    if (rst)
      state <= S0;
    else
      state <= next;
  end
endmodule
